export function renderCorrectionPreview(result){
 const p=result?.preview,valid=/^tg_[a-f0-9]{40}$/.test(p?.packageId??'')&&Number.isSafeInteger(p?.revision)&&p.revision>0&&/^[a-f0-9]{64}$/.test(p?.previewHash??'')&&['CREATE','UPDATE'].includes(p.action)&&['LITERAL','EDITORIAL'].includes(p.mode)&&['OPURO','OPOL','AMBOS','LIBERAL','OPURO,LIBERAL','OPOL,LIBERAL','TODOS'].includes(p.destination)&&Array.isArray(p.posts)&&Array.isArray(p.changes)&&Array.isArray(p.materials)&&Array.isArray(p.controlItemIds)&&new Set(p.controlItemIds).size===p.controlItemIds.length;
 if(!['PREVIEW_READY','PREVIEW_EXISTS'].includes(result?.status)||!valid)return {status:'PREVIEW_NOT_CONFIRMED',messages:['No pude preparar una vista previa verificable. El paquete sigue abierto y no se envió al Motor.']};
 const expected=p.destination==='TODOS'?['OPURO','OPOL','LIBERAL']:p.destination==='AMBOS'?['OPURO','OPOL']:p.destination.split(',');
 if(p.action==='UPDATE'&&(p.posts.length!==expected.length||p.posts.some((x,i)=>!x||x.destination!==expected[i]||!Number.isSafeInteger(x.postId)||x.postId<1)))return {status:'PREVIEW_NOT_CONFIRMED',messages:['No pude preparar una vista previa verificable. El paquete sigue abierto y no se envió al Motor.']};
 const controls=new Set(p.controlItemIds);
 const lines=[`Paquete: ${p.packageId}`,`Revisión: ${p.revision}`,`Acción: ${p.action==='UPDATE'?'actualizar notas existentes':'crear una nota nueva'}`,`Destinos: ${p.destination}`,`Modo: ${p.mode}`,p.action==='UPDATE'?`Identificadores de nota: ${p.posts.map(x=>`${x.destination} ${x.postId}`).join(', ')}`:'Identificadores de nota: aún no existen',`Cambios:`];
 if(p.action==='CREATE')lines.push(p.publicationMode==='DRAFT'?'Resultado autorizado: BORRADOR, sin publicación.':p.publicationMode==='PUBLISH'?'Resultado autorizado: PUBLICAR en los destinos indicados, sólo después de confirmar y superar la validación editorial.':'Resultado de publicación: debe verificarse con la orden conservada antes de escribir.');
 let changes=0;
 for(const x of p.changes){
  if(!/^ti_[a-f0-9]{40}$/.test(x?.itemId??'')||!['TEXT','FILE'].includes(x.kind)||!['ADDED','REMOVED'].includes(x.change)||!/^[a-f0-9]{64}$/.test(x.sha256??'')||(x.kind==='FILE'&&(typeof x.fileName!=='string'||typeof x.caption!=='string')))return {status:'PREVIEW_NOT_CONFIRMED',messages:['No pude preparar una vista previa verificable. El paquete sigue abierto y no se envió al Motor.']};
  if(controls.has(x.itemId))continue;
  changes++;lines.push(`${x.change==='ADDED'?'Agregado':'Retirado'} ${x.kind==='TEXT'?'texto':'archivo'} ${x.itemId}`);
  if(x.kind==='TEXT'&&typeof x.text==='string')lines.push(x.text);
  if(x.kind==='FILE'&&typeof x.fileName==='string')lines.push(`Nombre: ${x.fileName}`);
  if(x.kind==='FILE'&&typeof x.caption==='string'&&x.caption)lines.push(`Texto adjunto: ${x.caption}`);
 }
 if(!changes)lines.push('Sin cambios de material.');
 lines.push(Object.hasOwn(p,'finalPayloads')?'Materiales activos de esta revisión:':'Materiales activos de esta revisión (la nota final todavía no está generada):');
 let materials=0;const seen=new Set();
 for(const x of p.materials){
  if(!/^ti_[a-f0-9]{40}$/.test(x?.itemId??'')||seen.has(x.itemId)||!['TEXT','FILE'].includes(x.kind)||x.state!=='STORED'||!/^[a-f0-9]{64}$/.test(x.sha256??'')||(x.kind==='TEXT'&&typeof x.text!=='string')||(x.kind==='FILE'&&(typeof x.fileName!=='string'||typeof x.caption!=='string')))return {status:'PREVIEW_NOT_CONFIRMED',messages:['No pude preparar una vista previa verificable. El paquete sigue abierto y no se envió al Motor.']};
  seen.add(x.itemId);if(controls.has(x.itemId))continue;
  materials++;lines.push(`${x.kind==='TEXT'?'Texto':'Archivo'} ${x.itemId}\nSHA-256: ${x.sha256}`);if(x.kind==='TEXT')lines.push(x.text);
  if(x.kind==='FILE'&&typeof x.fileName==='string')lines.push(`Nombre: ${x.fileName}`);
  if(x.kind==='FILE'&&typeof x.caption==='string'&&x.caption)lines.push(`Texto adjunto: ${x.caption}`);
 }
 if(!materials||[...controls].some(id=>!seen.has(id)))return {status:'PREVIEW_NOT_CONFIRMED',messages:['No pude preparar una vista previa verificable. El paquete sigue abierto y no se envió al Motor.']};
 if(Object.hasOwn(p,'finalPayloads')){
  if(p.action!=='UPDATE'||!p.finalPayloads||typeof p.finalPayloads!=='object'||Array.isArray(p.finalPayloads)||Object.keys(p.finalPayloads).length!==expected.length||expected.some(d=>!Object.hasOwn(p.finalPayloads,d)))return {status:'PREVIEW_NOT_CONFIRMED',messages:['No pude preparar una vista previa verificable. El paquete sigue abierto y no se envió al Motor.']};
  let encoded;try{encoded=JSON.stringify(p.finalPayloads)}catch{return {status:'PREVIEW_NOT_CONFIRMED',messages:['No pude preparar una vista previa verificable. El paquete sigue abierto y no se envió al Motor.']}}
  if(typeof encoded!=='string'||encoded.length>16384)return {status:'PREVIEW_NOT_CONFIRMED',messages:['No pude preparar una vista previa verificable. El paquete sigue abierto y no se envió al Motor.']};
  for(const d of expected)lines.push(`Contenido exacto de actualización para ${d}:\n${JSON.stringify(p.finalPayloads[d])}`);
 }
 lines.push(`Para confirmar esta revisión, escribe:\n/confirmar ${p.action==='UPDATE'?'actualizar':'crear'} ${p.revision} ${p.previewHash}`);
 // Escape one code point at a time so no HTML entity or surrogate pair is
 // split across Telegram messages. The caller must deliver all parts in order.
 const escape=c=>c==='&'?'&amp;':c==='<'?'&lt;':c==='>'?'&gt;':c;
 const chunks=[];let chunk='';for(const char of lines.join('\n\n')){const part=escape(char);if(chunk.length+part.length>3000){chunks.push(chunk);chunk=''}chunk+=part}if(chunk)chunks.push(chunk);
 return {status:'PREVIEW_RENDERED',packageId:p.packageId,revision:p.revision,messages:chunks,parse_mode:'HTML'};
}
