import {resolveRecoveredPolicy} from './recovered-policy.mjs';
import {resolveDestinations,destinationLabel} from './original-destinations.mjs';

const fail=()=>{throw Error('CORRECTION_FACTS_UNCONFIRMED')};
const id=/^tg_[a-f0-9]{40}$/, hash=/^[a-f0-9]{64}$/;

// Called under the quota and package locks held by the confirmation store.
// The selection provider must read choices recorded from authenticated direct
// Telegram commands, under this transaction. Source material is never a choice.
// UPDATE additionally requires a server-owned provider which binds verified
// post IDs to this exact package, base revision, decision and destination.
// It is absent by default; a Telegram message must never provide these IDs.
export function createCorrectionFactsReader({readLockedSelection,readVerifiedUpdatePosts=null,readFinalPayloads=null}) {
 if(typeof readLockedSelection!=='function'||(readVerifiedUpdatePosts!==null&&typeof readVerifiedUpdatePosts!=='function')||(readFinalPayloads!==null&&typeof readFinalPayloads!=='function'))throw Error('CORRECTION_FACTS_CONFIGURATION_INCOMPLETE');
 return async function readFacts(c,{packageId,revision,ownerKey,actorKey=ownerKey}) {
  if(!c?.execute||!id.test(packageId??'')||!hash.test(ownerKey??'')||!hash.test(actorKey??'')||!Number.isSafeInteger(revision)||revision<2||revision>=4294967295)fail();
  const [leases]=await c.execute('SELECT actor_key,owner_key,opening_revision FROM opmx_tg_recovery_leases_v1 WHERE package_id=? FOR UPDATE',[packageId]);
  if(leases.length!==1||leases[0].owner_key!==ownerKey||leases[0].actor_key!==actorKey)fail();
  const baseRevision=Number(leases[0].opening_revision)-1;if(!Number.isSafeInteger(baseRevision)||baseRevision<1||baseRevision>=revision)fail();
  const [sessions]=await c.execute('SELECT package_id FROM opmx_tg_sessions_v1 WHERE owner_key=? FOR UPDATE',[actorKey]);
  if(sessions.length!==1||sessions[0].package_id!==packageId)fail();
  const [snapshots]=await c.execute('SELECT owner_key,snapshot_json FROM opmx_tg_revision_snapshots_v1 WHERE package_id=? AND revision=? FOR UPDATE',[packageId,baseRevision]);
  if(snapshots.length!==1||snapshots[0].owner_key!==ownerKey)fail();
  let snapshot;try{snapshot=JSON.parse(snapshots[0].snapshot_json)}catch{fail()}
  const [rows]=await c.execute('SELECT i.item_id,i.owner_key,i.receipt_key,i.fingerprint,i.kind,i.state,i.text_content,i.attachment_json,i.reserved_bytes,i.content_bytes,i.sha256,c.actor_key FROM opmx_tg_items_v1 i LEFT JOIN opmx_tg_recovery_contributions_v1 c ON c.item_id=i.item_id AND c.package_id=i.package_id WHERE i.package_id=? ORDER BY i.created_at,i.item_id FOR UPDATE',[packageId]);
  let items;try{items=rows.map(x=>({itemId:x.item_id,ownerKey:x.owner_key,receiptKey:x.receipt_key,fingerprint:x.fingerprint,kind:x.kind,state:x.state,text:x.text_content,attachment:x.attachment_json?JSON.parse(x.attachment_json):null,reservedBytes:Number(x.reserved_bytes),contentBytes:Number(x.content_bytes),sha256:x.sha256,actorKey:x.actor_key??null}))}catch{fail()}
  if(!items.length||items.some(x=>x.state==='PENDING'))fail();
  const close=items.at(-1);
  // Reuse the same immutable-inventory and attested-close checks as Motor.
  let verifiedPolicy;try{verifiedPolicy=resolveRecoveredPolicy({packageId,revision:revision+1,snapshot,closure:{packageId,revision:revision+1,snapshotRevision:baseRevision,actorKey,closeItemId:close.itemId,closeReceiptKey:close.receiptKey},items})}catch{fail()}
  const selection=await readLockedSelection(c,{packageId,revision,ownerKey,actorKey});
  if(!selection||selection.packageId!==packageId||selection.revision!==revision||selection.ownerKey!==ownerKey||!['CREATE','UPDATE'].includes(selection.action)||!['LITERAL','EDITORIAL'].includes(selection.mode))fail();
  // Never turn an existing or uncertain post into a new publication. A
  // creation decision is valid only when every original outcome is explicitly
  // reconciled as having no publication side effects.
  if(selection.action==='CREATE'){
   const p=snapshot?.prior;
   if(!p||!Array.isArray(p.destinations)||!p.destinations.length||!Array.isArray(p.results)||p.results.length!==p.destinations.length||new Set(p.results.map(x=>x?.destination)).size!==p.destinations.length||p.results.some(x=>!p.destinations.includes(x?.destination)||x.status!=='BLOCKED'||x.publicationVerdict!=='NO_PUBLICATION_SIDE_EFFECTS_CONFIRMED'))fail();
  }
  let destination;try{destination=destinationLabel(resolveDestinations(selection.destination));if(destination!==selection.destination)fail()}catch{fail()}
  let verifiedPosts={};
  if(selection.action==='UPDATE'){
   if(!readVerifiedUpdatePosts)fail();
   const evidence=await readVerifiedUpdatePosts(c,{packageId,revision,baseRevision,ownerKey,actorKey,destination});
   const destinations=resolveDestinations(destination);
   if(!evidence||evidence.packageId!==packageId||evidence.revision!==revision||evidence.baseRevision!==baseRevision||evidence.ownerKey!==ownerKey||evidence.actorKey!==actorKey||evidence.destination!==destination||evidence.verified!==true||!evidence.posts||typeof evidence.posts!=='object'||Array.isArray(evidence.posts)||Object.keys(evidence.posts).length!==destinations.length||destinations.some(d=>!Object.hasOwn(evidence.posts,d)||!Number.isSafeInteger(evidence.posts[d])||evidence.posts[d]<1))fail();
   verifiedPosts={...evidence.posts};
  }
  const visible=list=>list.filter(x=>x.sha256!==null).map(x=>{
   if(x.kind==='FILE'&&(!x.attachment||typeof x.attachment.file_name!=='string'||typeof x.text!=='string'))fail();
   return {itemId:x.itemId,kind:x.kind,state:x.state,sha256:x.sha256,...(x.kind==='TEXT'?{text:x.text}:{fileName:x.attachment.file_name,caption:x.text})};
  });
  if(!Array.isArray(snapshot.items))fail();
  let finalPayloads=null;
  if(selection.action==='UPDATE'&&readFinalPayloads){
   const scope={packageId,revision,baseRevision,ownerKey,actorKey,destination};
   const result=await readFinalPayloads(c,scope);
   // No proposal yet is different from an invalid proposal. Signal the
   // authenticated request to the server-owned preview producer; never
   // manufacture a preview or authorise an update from missing bytes.
   if(result===null)return {previewGenerationRequired:true,previewScope:scope};
   if(!result||Object.keys(scope).some(k=>result[k]!==scope[k])||!result.finalPayloads||typeof result.finalPayloads!=='object'||Array.isArray(result.finalPayloads))fail();
   finalPayloads=result.finalPayloads;
  }
  return {baseRevision,before:visible(snapshot.items),after:visible(items),action:selection.action,mode:selection.mode,destination,verifiedPosts,authorizedEditorKey:actorKey,controlItemIds:verifiedPolicy.control_item_ids,...(selection.action==='CREATE'?{publicationMode:verifiedPolicy.mode}:{}),...(finalPayloads?{finalPayloads}:{})};
 };
}
